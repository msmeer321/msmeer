/* =========================================
   MS MEER WEBSITE JAVASCRIPT
   ========================================= */

document.addEventListener("DOMContentLoaded", function () {

    /* =========================================
       SIGN UP / LOGIN (accounts kept in browser storage)
       ========================================= */
    const USERS_KEY = "msmeer_users";
    const SESSION_KEY = "msmeer_session";


    /* Session sirf is visit ke liye hai: site se bahar jane ya tab band karne par login khatam. */
    let keepSessionOnLeave = false;
    function sessionGet() { try { return sessionStorage.getItem(SESSION_KEY); } catch (err) { return null; } }
    function sessionSet(v) { try { sessionStorage.setItem(SESSION_KEY, v); } catch (err) {} }
    function sessionClear() { try { sessionStorage.removeItem(SESSION_KEY); } catch (err) {} }
    try { localStorage.removeItem(SESSION_KEY); } catch (err) {}  // purana "yaad rakho" login hata do
    window.addEventListener("pagehide", function () { if (!keepSessionOnLeave) sessionClear(); });
    window.addEventListener("pageshow", function (e) { if (e.persisted) location.reload(); });
    // Email / call buttons (order packages) khulne par login na jaye
    document.addEventListener("click", function (e) {
        const a = e.target.closest && e.target.closest("a[href^='mailto:'], a[href^='tel:']");
        if (a) { keepSessionOnLeave = true; setTimeout(function () { keepSessionOnLeave = false; }, 4000); }
    });

    function getUsers() {
        try { return JSON.parse(localStorage.getItem(USERS_KEY)) || []; }
        catch (err) { return []; }
    }
    function setUsers(list) {
        localStorage.setItem(USERS_KEY, JSON.stringify(list));
    }
    function getCurrentUser() {
        try {
            const email = sessionGet();
            if (!email) return null;
            return getUsers().find(function (u) { return u.email === email; }) || null;
        } catch (err) { return null; }
    }

    async function hashPassword(pw) {
        if (window.crypto && crypto.subtle) {
            const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("msmeer:" + pw));
            return Array.from(new Uint8Array(buf)).map(function (b) {
                return b.toString(16).padStart(2, "0");
            }).join("");
        }
        let h = 5381;
        for (let i = 0; i < pw.length; i++) h = ((h << 5) + h + pw.charCodeAt(i)) | 0;
        return "x" + h;
    }

    const authOverlay = document.getElementById("authOverlay");
    const signupForm = document.getElementById("signupForm");
    const loginForm = document.getElementById("loginForm");
    const tabSignup = document.getElementById("tabSignup");
    const tabLogin = document.getElementById("tabLogin");
    const authMessage = document.getElementById("authMessage");
    const userBox = document.getElementById("userBox");
    const userHello = document.getElementById("userHello");
    const logoutBtn = document.getElementById("logoutBtn");

    function authMsg(text, ok) {
        authMessage.textContent = text;
        authMessage.style.color = ok ? "#16a34a" : "#dc2626";
    }

    function showTab(which) {
        const isSignup = which === "signup";
        signupForm.hidden = !isSignup;
        loginForm.hidden = isSignup;
        tabSignup.classList.toggle("active", isSignup);
        tabLogin.classList.toggle("active", !isSignup);
        authMessage.textContent = "";
    }

    function applyAuthState() {
        const user = getCurrentUser();
        document.documentElement.classList.toggle("locked", !user);
        if (userBox) userBox.hidden = !user;
        if (user && userHello) userHello.textContent = "Hi, " + user.name;

        /* prefill order form name, show who is posting reviews */
        const orderName = document.getElementById("name");
        if (orderName && user && !orderName.value) orderName.value = user.name;
        const reviewAs = document.getElementById("reviewAs");
        if (reviewAs) {
            reviewAs.textContent = user
                ? "Posting as " + user.name + " (" + user.email + ")"
                : "Please login to post a review.";
        }
    }

    tabSignup.addEventListener("click", function () { showTab("signup"); });
    tabLogin.addEventListener("click", function () { showTab("login"); });

    signupForm.addEventListener("submit", async function (e) {
        e.preventDefault();
        const name = document.getElementById("suName").value.trim();
        const email = document.getElementById("suEmail").value.trim().toLowerCase();
        const pass = document.getElementById("suPass").value;
        const pass2 = document.getElementById("suPass2").value;

        if (!name || !email || !pass) { authMsg("Please fill all fields.", false); return; }
        if (pass.length < 6) { authMsg("Password must be at least 6 characters.", false); return; }
        if (pass !== pass2) { authMsg("Passwords do not match.", false); return; }

        const users = getUsers();
        if (users.some(function (u) { return u.email === email; })) {
            authMsg("This email is already registered. Please login.", false);
            return;
        }

        users.push({ name: name, email: email, hash: await hashPassword(pass) });
        try { setUsers(users); }
        catch (err) { authMsg("Could not save account. Please enable browser storage.", false); return; }

        signupForm.reset();
        showTab("login");
        document.getElementById("liEmail").value = email;
        authMsg("Account created! Now please login.", true);
    });

    loginForm.addEventListener("submit", async function (e) {
        e.preventDefault();
        const email = document.getElementById("liEmail").value.trim().toLowerCase();
        const pass = document.getElementById("liPass").value;
        const user = getUsers().find(function (u) { return u.email === email; });

        if (!user) { authMsg("No account found. Please sign up first.", false); return; }
        if (user.hash !== await hashPassword(pass)) { authMsg("Wrong password.", false); return; }

        sessionSet(user.email);
        loginForm.reset();
        authMessage.textContent = "";
        applyAuthState();
        window.scrollTo({ top: 0 });
    });

    logoutBtn.addEventListener("click", function () {
        sessionClear();
        showTab("login");
        applyAuthState();
    });

    applyAuthState();


    /* ---------- CURRENT YEAR ---------- */
    const yearElement = document.getElementById("year");
    if (yearElement) yearElement.textContent = new Date().getFullYear();


    /* ---------- BACK TO TOP BUTTON ---------- */
    const topBtn = document.getElementById("topBtn");
    if (topBtn) {
        window.addEventListener("scroll", function () {
            topBtn.classList.toggle("show", window.scrollY > 400);
        });
        topBtn.addEventListener("click", function () {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }


    /* ---------- ORDER FORM (sends order to Gmail: sananone16@gmail.com) ---------- */
    const orderForm = document.getElementById("orderForm");
    if (orderForm) {
        orderForm.addEventListener("submit", function (e) {
            e.preventDefault();

            const user = getCurrentUser();
            if (!user) {
                alert("Please login first to submit an order.");
                showTab("login");
                applyAuthState();
                return;
            }

            const name = document.getElementById("name").value.trim();
            const phone = document.getElementById("phone").value.trim();
            const business = document.getElementById("business").value.trim();
            const service = document.getElementById("service").value;
            const details = document.getElementById("message").value.trim();

            if (!name || !phone || !business || !service || !details) {
                alert("Please fill all required fields.");
                return;
            }

            const subject = "New Website Order - " + service;
            const body =
                "Hello MS MEER,\n\n" +
                "I want to order a website.\n\n" +
                "Name: " + name + "\n" +
                "Account Email: " + user.email + "\n" +
                "Phone: " + phone + "\n" +
                "Business/Website: " + business + "\n" +
                "Package: " + service + "\n" +
                "Project Details: " + details;

            const gmailUrl =
                "https://mail.google.com/mail/?view=cm&fs=1" +
                "&to=" + encodeURIComponent("sananone16@gmail.com") +
                "&su=" + encodeURIComponent(subject) +
                "&body=" + encodeURIComponent(body);

            window.open(gmailUrl, "_blank");
            orderForm.reset();
            applyAuthState();
        });
    }


    /* =========================================
       REVIEWS & FEEDBACK (public, visible to everyone)
       Reviews are saved in the visitor's browser storage
       and rendered on the page for every visitor to read.
       ========================================= */

    const STORAGE_KEY = "msmeer_reviews";

    const seedReviews = [
        { name: "Ali Raza", email: "ali.raza@example.com", rating: 5, review: "MS MEER built our business site fast and it looks amazing on mobile.", date: "2025-11-02" },
        { name: "Sana Khan", email: "sana.khan@example.com", rating: 5, review: "Very professional communication and delivered exactly what we asked for.", date: "2025-12-14" },
        { name: "Bilal Ahmed", email: "bilal.ahmed@example.com", rating: 4, review: "Great design work, quick replies on WhatsApp. Recommended.", date: "2026-02-08" }
    ];

    function loadReviews() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            const saved = raw ? JSON.parse(raw) : [];
            return seedReviews.concat(saved);
        } catch (err) {
            return seedReviews;
        }
    }

    function saveReview(entry) {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            const saved = raw ? JSON.parse(raw) : [];
            saved.unshift(entry);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
        } catch (err) {
            /* storage unavailable (private browsing etc.) - review still shows this session */
        }
    }

    function starString(rating) {
        return "★".repeat(rating) + "☆".repeat(5 - rating);
    }

    function renderReviews() {
        const list = document.getElementById("reviewsList");
        if (!list) return;

        const reviews = loadReviews();

        list.innerHTML = "";
        reviews.forEach(function (r) {
            const card = document.createElement("div");
            card.className = "review-card";
            card.innerHTML =
                '<span class="review-stars">' + starString(r.rating) + "</span>" +
                "<p>" + escapeHtml(r.review) + "</p>" +
                "<strong>" + escapeHtml(r.name) + "</strong>" +
                (r.email ? '<span class="review-email">' + escapeHtml(r.email) + "</span>" : "");
            list.appendChild(card);
        });
    }

    function escapeHtml(str) {
        const div = document.createElement("div");
        div.textContent = str;
        return div.innerHTML;
    }

    /* Clickable star rating picker */
    const stars = document.querySelectorAll("#reviews .stars span");
    const ratingInput = document.getElementById("ratingValue");
    const form = document.getElementById("feedbackForm");
    const message = document.getElementById("feedbackMessage");

    function setRating(value) {
        if (value > 0 && !getCurrentUser()) {
            if (message) {
                message.textContent = "Please login first to give a rating.";
                message.style.color = "#dc2626";
            }
            return;
        }
        if (ratingInput) ratingInput.value = value;
        stars.forEach(function (star) {
            star.classList.toggle("selected", Number(star.dataset.value) <= value);
        });
        if (message && value > 0) {
            message.textContent = value + " / 5 stars selected";
            message.style.color = "#0878ff";
        }
    }

    stars.forEach(function (star) {
        star.addEventListener("click", function () {
            setRating(Number(star.dataset.value));
        });
        star.addEventListener("keydown", function (e) {
            if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                setRating(Number(star.dataset.value));
            }
        });
    });

    if (form) {
        form.addEventListener("submit", function (e) {
            e.preventDefault();

            const user = getCurrentUser();
            if (!user) {
                message.textContent = "Please login first to post a rating or review.";
                message.style.color = "#dc2626";
                showTab("login");
                applyAuthState();
                return;
            }

            const rating = Number(ratingInput.value);

            if (rating < 1) {
                message.textContent = "Please select a star rating first.";
                message.style.color = "#dc2626";
                return;
            }

            const review = document.getElementById("reviewText").value.trim();

            if (!review) {
                message.textContent = "Please write your review.";
                message.style.color = "#dc2626";
                return;
            }

            const entry = {
                name: user.name,
                email: user.email,
                rating: rating,
                review: review,
                date: new Date().toISOString().slice(0, 10)
            };

            saveReview(entry);
            renderReviews();

            message.textContent = "Thank you! Your review is now posted below.";
            message.style.color = "#0878ff";

            form.reset();
            setRating(0);
        });
    }

    renderReviews();
});
